import React, { useState, useEffect } from 'react';
import { MOCK_STOCKS, Stock } from '../types';
import { Search, Filter, ArrowUpRight, ArrowDownRight, MoreHorizontal, RefreshCw } from 'lucide-react';
import { RealTimeFeed } from './RealTimeFeed';
import { cn } from '../lib/utils';

export const MarketView: React.FC = () => {
  const [stocks, setStocks] = useState<Stock[]>(MOCK_STOCKS);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<string>(new Date().toLocaleTimeString());
  const [selectedSymbol, setSelectedSymbol] = useState<string>('AAPL');

  const fetchLivePrices = async () => {
    setLoading(true);
    try {
      const updatedStocks = await Promise.all(
        stocks.map(async (stock) => {
          try {
            const res = await fetch(`/api/market/quote/${stock.symbol}`);
            if (!res.ok) return stock;
            const data = await res.json();
            
            // Finnhub quote response: c = current price, d = change, dp = percent change
            if (data.c) {
              return {
                ...stock,
                price: data.c,
                change: data.d,
                changePercent: data.dp
              };
            }
            return stock;
          } catch (e) {
            return stock;
          }
        })
      );
      setStocks(updatedStocks);
      setLastUpdate(new Date().toLocaleTimeString());
    } catch (error) {
      console.error("Failed to update prices:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLivePrices();
    const interval = setInterval(fetchLivePrices, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-8 space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Market Explorer</h1>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-zinc-500">Global market data and real-time stock feeds.</p>
            <span className="text-zinc-700">•</span>
            <span className="text-xs text-zinc-500 font-mono">Last update: {lastUpdate}</span>
          </div>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={fetchLivePrices}
            disabled={loading}
            className="p-2.5 bg-[#151518] border border-[#1F1F22] rounded-xl text-zinc-400 hover:text-white transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input 
              type="text" 
              placeholder="Search symbols..." 
              className="bg-[#151518] border border-[#1F1F22] rounded-xl pl-10 pr-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-600 transition-colors w-64"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2.5 bg-[#151518] border border-[#1F1F22] rounded-xl text-zinc-400 text-sm hover:text-white transition-colors">
            <Filter className="w-4 h-4" />
            <span>Filters</span>
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 bg-[#151518] rounded-2xl border border-[#1F1F22] overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#1A1A1D] border-b border-[#1F1F22]">
                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest">Symbol</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest">Name</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest">Price</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest">Change</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest">Volume</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F22]">
              {stocks.map((stock) => (
                <tr 
                  key={stock.symbol} 
                  onClick={() => setSelectedSymbol(stock.symbol)}
                  className={cn(
                    "hover:bg-[#1A1A1D] transition-colors group cursor-pointer",
                    selectedSymbol === stock.symbol && "bg-[#1A1A1D] border-l-2 border-l-blue-600"
                  )}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-600/10 text-blue-500 flex items-center justify-center font-bold text-xs">
                        {stock.symbol[0]}
                      </div>
                      <span className="text-white font-bold">{stock.symbol}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-zinc-400 text-sm">{stock.name}</td>
                  <td className="px-6 py-4 text-white font-medium">${stock.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                  <td className="px-6 py-4">
                    <div className={`flex items-center gap-1 text-sm font-medium ${stock.change >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                      {stock.change >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                      {Math.abs(stock.changePercent).toFixed(2)}%
                    </div>
                  </td>
                  <td className="px-6 py-4 text-zinc-500 text-sm">{stock.volume}</td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 rounded-lg hover:bg-[#1F1F22] text-zinc-500 hover:text-white transition-colors">
                      <MoreHorizontal className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="lg:col-span-1 h-[600px]">
          <RealTimeFeed 
            selectedSymbol={selectedSymbol} 
            onSymbolChange={setSelectedSymbol}
            monitoredSymbols={stocks.map(s => s.symbol)}
          />
        </div>
      </div>
    </div>
  );
};

