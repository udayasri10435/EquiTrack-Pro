import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Wallet, TrendingUp, ArrowUpRight, ArrowDownRight } from 'lucide-react';

const portfolioData = [
  { name: 'Technology', value: 45, color: '#3b82f6' },
  { name: 'Healthcare', value: 15, color: '#10b981' },
  { name: 'Financials', value: 20, color: '#f59e0b' },
  { name: 'Energy', value: 10, color: '#ef4444' },
  { name: 'Others', value: 10, color: '#8b5cf6' },
];

const holdings = [
  { symbol: 'AAPL', shares: 150, avgPrice: 145.20, currentPrice: 182.52, pnl: '+25.7%' },
  { symbol: 'NVDA', shares: 45, avgPrice: 420.50, currentPrice: 875.28, pnl: '+108.1%' },
  { symbol: 'MSFT', shares: 80, avgPrice: 310.15, currentPrice: 415.10, pnl: '+33.8%' },
  { symbol: 'GOOGL', shares: 120, avgPrice: 125.40, currentPrice: 147.60, pnl: '+17.7%' },
];

export const PortfolioView: React.FC = () => {
  return (
    <div className="p-8 space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-white">My Portfolio</h1>
        <p className="text-zinc-500 mt-1">Detailed analysis of your asset allocation and holdings.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 bg-[#151518] rounded-2xl border border-[#1F1F22] p-6">
          <h2 className="text-xl font-semibold text-white mb-6">Asset Allocation</h2>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={portfolioData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {portfolioData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#151518', border: '1px solid #1F1F22', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-3 mt-4">
            {portfolioData.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-sm text-zinc-400">{item.name}</span>
                </div>
                <span className="text-sm font-bold text-white">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl p-8 text-white relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-500">
              <Wallet className="w-32 h-32" />
            </div>
            <div className="relative z-10">
              <div className="text-blue-100 text-sm font-medium uppercase tracking-wider">Total Balance</div>
              <div className="text-4xl font-bold mt-2">$1,284,502.42</div>
              <div className="flex items-center gap-2 mt-4 text-blue-100">
                <div className="flex items-center gap-1 bg-white/20 px-2 py-1 rounded-lg text-xs font-bold">
                  <ArrowUpRight className="w-3 h-3" />
                  +12.5%
                </div>
                <span className="text-sm opacity-80">vs last month</span>
              </div>
            </div>
          </div>

          <div className="bg-[#151518] rounded-2xl border border-[#1F1F22] overflow-hidden">
            <div className="p-6 border-b border-[#1F1F22]">
              <h2 className="text-xl font-semibold text-white">Current Holdings</h2>
            </div>
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#1A1A1D] border-b border-[#1F1F22]">
                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest">Asset</th>
                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest text-right">Shares</th>
                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest text-right">Avg Price</th>
                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest text-right">Current</th>
                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-widest text-right">P&L</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F1F22]">
                {holdings.map((h) => (
                  <tr key={h.symbol} className="hover:bg-[#1A1A1D] transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-zinc-800 flex items-center justify-center font-bold text-xs text-zinc-400">
                          {h.symbol[0]}
                        </div>
                        <span className="text-white font-bold">{h.symbol}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right text-zinc-400 font-mono">{h.shares}</td>
                    <td className="px-6 py-4 text-right text-zinc-400 font-mono">${h.avgPrice}</td>
                    <td className="px-6 py-4 text-right text-white font-bold font-mono">${h.currentPrice}</td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-emerald-500 font-bold text-sm">{h.pnl}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
