import React from 'react';
import { 
  LayoutDashboard, 
  LineChart, 
  Briefcase, 
  ShieldCheck, 
  Bell, 
  Settings, 
  Network,
  LogOut,
  TrendingUp
} from 'lucide-react';
import { cn } from '../lib/utils';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'market', label: 'Market Data', icon: LineChart },
    { id: 'portfolio', label: 'Portfolio', icon: Briefcase },
    { id: 'risk', label: 'Risk & Compliance', icon: ShieldCheck },
    { id: 'architecture', label: 'Architecture', icon: Network },
    { id: 'alerts', label: 'Alerts', icon: Bell },
  ];

  return (
    <div className="w-64 bg-[#0A0A0B] border-r border-[#1F1F22] flex flex-col h-screen sticky top-0">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
          <TrendingUp className="text-white w-5 h-5" />
        </div>
        <span className="text-white font-bold text-xl tracking-tight">EquiTrack</span>
      </div>

      <nav className="flex-1 px-4 space-y-1 mt-4">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
              activeTab === item.id 
                ? "bg-blue-600/10 text-blue-500" 
                : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50"
            )}
          >
            <item.icon className={cn(
              "w-5 h-5",
              activeTab === item.id ? "text-blue-500" : "text-zinc-500 group-hover:text-zinc-300"
            )} />
            <span className="font-medium">{item.label}</span>
            {activeTab === item.id && (
              <div className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-500" />
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-[#1F1F22]">
        <button className="w-full flex items-center gap-3 px-4 py-3 text-zinc-500 hover:text-zinc-300 transition-colors">
          <Settings className="w-5 h-5" />
          <span className="font-medium">Settings</span>
        </button>
        <button className="w-full flex items-center gap-3 px-4 py-3 text-red-500/70 hover:text-red-500 transition-colors">
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </div>
  );
};
