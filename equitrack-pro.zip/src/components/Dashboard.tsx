import React from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { ArrowUpRight, ArrowDownRight, DollarSign, Activity, PieChart as PieIcon } from 'lucide-react';
import { MOCK_STOCKS } from '../types';

const data = [
  { time: '09:30', value: 4200 },
  { time: '10:30', value: 4250 },
  { time: '11:30', value: 4220 },
  { time: '12:30', value: 4300 },
  { time: '13:30', value: 4280 },
  { time: '14:30', value: 4350 },
  { time: '15:30', value: 4400 },
];

export const Dashboard: React.FC = () => {
  return (
    <div className="p-8 space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-white">Market Overview</h1>
        <p className="text-zinc-500 mt-1">Real-time insights across your enterprise portfolio.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total NAV" 
          value="$1,284,502.42" 
          change="+12.5%" 
          isPositive={true} 
          icon={DollarSign}
        />
        <StatCard 
          title="Daily P&L" 
          value="+$14,205.10" 
          change="+2.4%" 
          isPositive={true} 
          icon={Activity}
        />
        <StatCard 
          title="Open Orders" 
          value="24" 
          change="-2" 
          isPositive={false} 
          icon={PieIcon}
        />
        <StatCard 
          title="Risk Score" 
          value="Low" 
          change="Stable" 
          isPositive={true} 
          icon={Activity}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-[#151518] rounded-2xl border border-[#1F1F22] p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">S&P 500 Performance</h2>
            <div className="flex gap-2">
              {['1D', '1W', '1M', '1Y', 'ALL'].map(t => (
                <button key={t} className="px-3 py-1 text-xs font-medium rounded-lg bg-[#1F1F22] text-zinc-400 hover:text-white transition-colors">
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F1F22" vertical={false} />
                <XAxis 
                  dataKey="time" 
                  stroke="#52525b" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  stroke="#52525b" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#151518', border: '1px solid #1F1F22', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#3b82f6" 
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-[#151518] rounded-2xl border border-[#1F1F22] p-6">
          <h2 className="text-xl font-semibold text-white mb-6">Top Movers</h2>
          <div className="space-y-4">
            {MOCK_STOCKS.slice(0, 5).map((stock) => (
              <div key={stock.symbol} className="flex items-center justify-between group cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#1F1F22] flex items-center justify-center font-bold text-zinc-300 group-hover:bg-blue-600/20 group-hover:text-blue-500 transition-colors">
                    {stock.symbol[0]}
                  </div>
                  <div>
                    <div className="text-white font-medium">{stock.symbol}</div>
                    <div className="text-zinc-500 text-xs">{stock.name}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-white font-medium">${stock.price}</div>
                  <div className={`text-xs flex items-center justify-end gap-1 ${stock.change >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                    {stock.change >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {Math.abs(stock.changePercent)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-3 rounded-xl bg-[#1F1F22] text-zinc-400 text-sm font-medium hover:text-white hover:bg-[#27272a] transition-all">
            View All Market Data
          </button>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, change, isPositive, icon: Icon }: any) => (
  <div className="bg-[#151518] rounded-2xl border border-[#1F1F22] p-6 hover:border-zinc-700 transition-all group">
    <div className="flex items-center justify-between mb-4">
      <div className="p-2 rounded-lg bg-[#1F1F22] text-zinc-400 group-hover:text-blue-500 transition-colors">
        <Icon className="w-5 h-5" />
      </div>
      <div className={`text-xs font-medium px-2 py-1 rounded-full ${isPositive ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
        {change}
      </div>
    </div>
    <div className="text-zinc-500 text-sm font-medium">{title}</div>
    <div className="text-2xl font-bold text-white mt-1">{value}</div>
  </div>
);
