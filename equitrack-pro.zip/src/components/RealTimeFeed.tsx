import React, { useState, useEffect } from 'react';
import { MOCK_STOCKS } from '../types';
import { ArrowUpRight, ArrowDownRight, Activity, RefreshCw, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface TradeEvent {
  id: string;
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  timestamp: string;
}

interface DetailedQuote {
  c: number; // current
  d: number; // change
  dp: number; // percent change
  h: number; // high
  l: number; // low
  o: number; // open
  pc: number; // prev close
}

interface RealTimeFeedProps {
  monitoredSymbols?: string[];
  selectedSymbol: string;
  onSymbolChange: (symbol: string) => void;
}

const DEFAULT_SYMBOLS = ['AAPL', 'MSFT', 'NVDA', 'TSLA', 'GOOGL'];

export const RealTimeFeed: React.FC<RealTimeFeedProps> = ({ 
  monitoredSymbols = DEFAULT_SYMBOLS,
  selectedSymbol,
  onSymbolChange
}) => {
  const [events, setEvents] = useState<TradeEvent[]>([]);
  const [detailedQuote, setDetailedQuote] = useState<DetailedQuote | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch detailed quote for selected symbol
  useEffect(() => {
    const fetchDetailed = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/market/quote/${selectedSymbol}`);
        if (!res.ok) throw new Error(`Failed to fetch ${selectedSymbol}`);
        const data = await res.json();
        if (data.c) {
          setDetailedQuote(data);
        } else {
          throw new Error("Invalid data received");
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unknown error");
      } finally {
        setLoading(false);
      }
    };

    fetchDetailed();
    const interval = setInterval(fetchDetailed, 10000); // Detailed view updates every 10s
    return () => clearInterval(interval);
  }, [selectedSymbol]);

  // Background stream for all monitored symbols
  useEffect(() => {
    let currentIndex = 0;
    const fetchStream = async () => {
      const symbol = monitoredSymbols[currentIndex];
      try {
        const res = await fetch(`/api/market/quote/${symbol}`);
        if (!res.ok) return;
        const data = await res.json();
        
        if (data.c) {
          const newEvent: TradeEvent = {
            id: Math.random().toString(36).substr(2, 9),
            symbol: symbol,
            price: data.c,
            change: data.d,
            changePercent: data.dp,
            timestamp: new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          };
          setEvents(prev => [newEvent, ...prev].slice(0, 15));
        }
      } catch (e) {
        // Silent fail for background stream
      }
      currentIndex = (currentIndex + 1) % monitoredSymbols.length;
    };

    const interval = setInterval(fetchStream, 3000); // Stream updates every 3s
    return () => clearInterval(interval);
  }, [monitoredSymbols]);

  return (
    <div className="bg-[#151518] rounded-2xl border border-[#1F1F22] overflow-hidden flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-[#1F1F22] flex items-center justify-between bg-[#1A1A1D]">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-blue-500 animate-pulse" />
          <h2 className="text-sm font-bold text-white uppercase tracking-wider">Market Pulse</h2>
        </div>
        <div className="flex items-center gap-2">
          {loading && <RefreshCw className="w-3 h-3 text-zinc-500 animate-spin" />}
          <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full uppercase">
            Live
          </span>
        </div>
      </div>

      {/* Detailed View */}
      <div className="p-4 border-b border-[#1F1F22] bg-gradient-to-b from-[#1A1A1D] to-[#151518]">
        {error ? (
          <div className="flex items-center gap-2 text-rose-500 text-xs p-2 bg-rose-500/10 rounded-lg border border-rose-500/20">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        ) : detailedQuote ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold text-white tracking-tight">{selectedSymbol}</span>
                <span className="text-xs text-zinc-500 font-medium">Real-time</span>
              </div>
              <div className="text-right">
                <div className="text-2xl font-mono font-bold text-white">${detailedQuote.c.toFixed(2)}</div>
                <div className={cn(
                  "text-xs font-bold flex items-center justify-end gap-1",
                  detailedQuote.d >= 0 ? "text-emerald-500" : "text-rose-500"
                )}>
                  {detailedQuote.d >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {Math.abs(detailedQuote.dp).toFixed(2)}%
                </div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#1F1F22]">
              <div>
                <div className="text-[10px] text-zinc-500 uppercase font-bold">High</div>
                <div className="text-xs text-white font-mono">${detailedQuote.h.toFixed(2)}</div>
              </div>
              <div>
                <div className="text-[10px] text-zinc-500 uppercase font-bold">Low</div>
                <div className="text-xs text-white font-mono">${detailedQuote.l.toFixed(2)}</div>
              </div>
              <div>
                <div className="text-[10px] text-zinc-500 uppercase font-bold">Open</div>
                <div className="text-xs text-white font-mono">${detailedQuote.o.toFixed(2)}</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-24 flex items-center justify-center">
            <RefreshCw className="w-6 h-6 text-zinc-700 animate-spin" />
          </div>
        )}
      </div>

      {/* Symbol Selector */}
      <div className="px-4 py-2 border-b border-[#1F1F22] flex gap-2 overflow-x-auto no-scrollbar">
        {monitoredSymbols.map(s => (
          <button
            key={s}
            onClick={() => onSymbolChange(s)}
            className={cn(
              "px-3 py-1 rounded-full text-[10px] font-bold transition-all whitespace-nowrap",
              selectedSymbol === s 
                ? "bg-blue-600 text-white" 
                : "bg-[#1F1F22] text-zinc-500 hover:text-zinc-300"
            )}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Recent Trades Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <div className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest mb-2">Recent Trades</div>
        <AnimatePresence initial={false}>
          {events.map((event) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className={cn(
                "flex items-center justify-between p-3 rounded-xl border transition-all",
                event.symbol === selectedSymbol 
                  ? "bg-blue-600/5 border-blue-600/20" 
                  : "bg-[#1A1A1D] border-[#1F1F22] hover:border-zinc-700"
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs",
                  event.symbol === selectedSymbol ? "bg-blue-600 text-white" : "bg-zinc-800 text-zinc-400"
                )}>
                  {event.symbol[0]}
                </div>
                <div>
                  <div className="text-white font-bold text-xs">{event.symbol}</div>
                  <div className="text-[10px] text-zinc-500">{event.timestamp}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white font-mono text-xs font-bold">${event.price.toFixed(2)}</div>
                <div className={`text-[10px] font-bold flex items-center justify-end gap-0.5 ${event.change >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                  {event.change >= 0 ? <ArrowUpRight className="w-2.5 h-2.5" /> : <ArrowDownRight className="w-2.5 h-2.5" />}
                  {Math.abs(event.changePercent).toFixed(2)}%
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {events.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-zinc-600 space-y-2 py-12">
            <Activity className="w-8 h-8 opacity-20" />
            <span className="text-xs">Connecting to market data...</span>
          </div>
        )}
      </div>
    </div>
  );
};
