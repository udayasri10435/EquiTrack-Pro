import React from 'react';
import { ARCHITECTURE_DATA } from '../types';
import { 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  Server, 
  Database, 
  Cpu, 
  Globe, 
  Lock, 
  MessageSquare,
  Activity
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

export const ArchitectureExplorer: React.FC = () => {
  return (
    <div className="p-8 space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">System Architecture</h1>
          <p className="text-zinc-500 mt-1">Live status of 200+ microservices across 8 bounded contexts.</p>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 text-emerald-500 rounded-lg border border-emerald-500/20">
            <CheckCircle2 className="w-4 h-4" />
            <span className="text-sm font-medium">192 Healthy</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/10 text-amber-500 rounded-lg border border-amber-500/20">
            <AlertCircle className="w-4 h-4" />
            <span className="text-sm font-medium">6 Warning</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-rose-500/10 text-rose-500 rounded-lg border border-rose-500/20">
            <XCircle className="w-4 h-4" />
            <span className="text-sm font-medium">2 Error</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
        <div className="bg-blue-600/10 border border-blue-600/20 rounded-2xl p-6 flex items-center gap-4">
          <div className="p-3 bg-blue-600 rounded-xl text-white">
            <Globe className="w-6 h-6" />
          </div>
          <div>
            <div className="text-zinc-400 text-xs uppercase tracking-wider font-bold">API Gateway</div>
            <div className="text-white font-bold text-lg">Kong Mesh</div>
          </div>
        </div>
        <div className="bg-purple-600/10 border border-purple-600/20 rounded-2xl p-6 flex items-center gap-4">
          <div className="p-3 bg-purple-600 rounded-xl text-white">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <div className="text-zinc-400 text-xs uppercase tracking-wider font-bold">Event Bus</div>
            <div className="text-white font-bold text-lg">Apache Kafka</div>
          </div>
        </div>
        <div className="bg-emerald-600/10 border border-emerald-600/20 rounded-2xl p-6 flex items-center gap-4">
          <div className="p-3 bg-emerald-600 rounded-xl text-white">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <div className="text-zinc-400 text-xs uppercase tracking-wider font-bold">Persistence</div>
            <div className="text-white font-bold text-lg">Polyglot DB</div>
          </div>
        </div>
        <div className="bg-zinc-800 border border-zinc-700 rounded-2xl p-6 flex items-center gap-4">
          <div className="p-3 bg-zinc-700 rounded-xl text-white">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <div className="text-zinc-400 text-xs uppercase tracking-wider font-bold">Secrets</div>
            <div className="text-white font-bold text-lg">HashiCorp Vault</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {ARCHITECTURE_DATA.map((context, idx) => (
          <motion.div 
            key={context.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-[#151518] rounded-2xl border border-[#1F1F22] overflow-hidden"
          >
            <div className="p-6 border-b border-[#1F1F22] flex items-center justify-between bg-[#1A1A1D]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600/10 text-blue-500 flex items-center justify-center">
                  <Server className="w-5 h-5" />
                </div>
                <h2 className="text-xl font-bold text-white">{context.name}</h2>
              </div>
              <span className="text-xs font-bold text-zinc-500 uppercase tracking-widest bg-[#1F1F22] px-3 py-1 rounded-full">
                {context.services.length} Services
              </span>
            </div>
            <div className="p-4 grid grid-cols-1 gap-3">
              {context.services.map((service) => (
                <div 
                  key={service.id} 
                  className="flex items-center justify-between p-4 rounded-xl bg-[#1A1A1D] border border-[#1F1F22] hover:border-zinc-700 transition-all group"
                >
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      service.status === 'healthy' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' :
                      service.status === 'warning' ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]' :
                      'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]'
                    )} />
                    <div>
                      <div className="text-white font-medium group-hover:text-blue-400 transition-colors">{service.name}</div>
                      <div className="text-zinc-500 text-xs">{service.description}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex -space-x-2">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="w-6 h-6 rounded-full bg-zinc-800 border-2 border-[#1A1A1D] flex items-center justify-center text-[8px] text-zinc-500 font-bold">
                          K8S
                        </div>
                      ))}
                    </div>
                    <Activity className="w-4 h-4 text-zinc-700 group-hover:text-blue-500 transition-colors" />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-blue-600/5 border border-blue-600/10 rounded-2xl p-8 flex flex-col items-center text-center space-y-4">
        <Cpu className="w-12 h-12 text-blue-500" />
        <h3 className="text-2xl font-bold text-white">Infrastructure Overview</h3>
        <p className="text-zinc-400 max-w-2xl">
          Our system leverages a Service Mesh (Istio) for east-west traffic management, 
          mTLS for zero-trust security, and Apache Kafka for high-throughput event-driven 
          communication. Each bounded context is isolated within dedicated Kubernetes namespaces.
        </p>
        <div className="flex gap-8 pt-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-white">99.99%</div>
            <div className="text-zinc-500 text-sm">System Uptime</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white">1.2M</div>
            <div className="text-zinc-500 text-sm">Events / Sec</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white">42ms</div>
            <div className="text-zinc-500 text-sm">Avg. Latency</div>
          </div>
        </div>
      </div>
    </div>
  );
};
