/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { MarketView } from './components/MarketView';
import { ArchitectureExplorer } from './components/ArchitectureExplorer';
import { PortfolioView } from './components/PortfolioView';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'market':
        return <MarketView />;
      case 'architecture':
        return <ArchitectureExplorer />;
      case 'portfolio':
        return <PortfolioView />;
      default:
        return (
          <div className="p-8 flex flex-col items-center justify-center h-[80vh] text-center space-y-4">
            <h2 className="text-2xl font-bold text-white">Module Under Construction</h2>
            <p className="text-zinc-500">This microservice context is currently being deployed.</p>
          </div>
        );
    }
  };

  return (
    <div className="flex min-h-screen bg-[#0A0A0B] font-sans text-zinc-300 antialiased selection:bg-blue-500/30">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
}

