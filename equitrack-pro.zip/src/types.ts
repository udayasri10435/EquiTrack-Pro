export interface Stock {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: string;
  marketCap: string;
}

export interface Holding {
  symbol: string;
  shares: number;
  avgPrice: number;
  currentPrice: number;
}

export interface Microservice {
  id: string;
  name: string;
  description: string;
  status: 'healthy' | 'warning' | 'error';
}

export interface BoundedContext {
  name: string;
  icon: string;
  services: Microservice[];
}

export const MOCK_STOCKS: Stock[] = [
  { symbol: 'AAPL', name: 'Apple Inc.', price: 182.52, change: 1.25, changePercent: 0.69, volume: '52.4M', marketCap: '2.85T' },
  { symbol: 'MSFT', name: 'Microsoft Corp.', price: 415.10, change: -2.30, changePercent: -0.55, volume: '21.1M', marketCap: '3.08T' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', price: 147.60, change: 0.85, changePercent: 0.58, volume: '18.5M', marketCap: '1.84T' },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', price: 175.35, change: 3.12, changePercent: 1.81, volume: '35.2M', marketCap: '1.82T' },
  { symbol: 'NVDA', name: 'NVIDIA Corp.', price: 875.28, change: 15.40, changePercent: 1.79, volume: '48.9M', marketCap: '2.19T' },
  { symbol: 'TSLA', name: 'Tesla Inc.', price: 171.05, change: -4.20, changePercent: -2.40, volume: '82.1M', marketCap: '544B' },
  { symbol: 'META', name: 'Meta Platforms Inc.', price: 496.24, change: 5.12, changePercent: 1.04, volume: '15.8M', marketCap: '1.26T' },
];

export const ARCHITECTURE_DATA: BoundedContext[] = [
  {
    name: 'User & Identity',
    icon: 'User',
    services: [
      { id: 'u1', name: 'User Registration', description: 'Handles new user signups', status: 'healthy' },
      { id: 'u2', name: 'Auth (OAuth2/JWT)', description: 'Identity provider service', status: 'healthy' },
      { id: 'u3', name: 'RBAC Engine', description: 'Role-based access control', status: 'healthy' },
      { id: 'u4', name: 'KYC Verification', description: 'Know Your Customer processing', status: 'warning' },
      { id: 'u5', name: 'MFA Service', description: 'Multi-factor authentication', status: 'healthy' },
    ]
  },
  {
    name: 'Market Data',
    icon: 'BarChart3',
    services: [
      { id: 'm1', name: 'NYSE Ingest', description: 'Real-time feed from NYSE', status: 'healthy' },
      { id: 'm2', name: 'NASDAQ Ingest', description: 'Real-time feed from NASDAQ', status: 'healthy' },
      { id: 'm3', name: 'Historical Engine', description: 'Time-series data retrieval', status: 'healthy' },
      { id: 'm4', name: 'News Sentiment', description: 'AI-driven news analysis', status: 'healthy' },
      { id: 'm5', name: 'Forex Ingest', description: 'Currency exchange rates', status: 'error' },
    ]
  },
  {
    name: 'Portfolio Management',
    icon: 'Briefcase',
    services: [
      { id: 'p1', name: 'Valuation Engine', description: 'Real-time NAV calculation', status: 'healthy' },
      { id: 'p2', name: 'Tax Lot Accounting', description: 'Cost basis tracking', status: 'healthy' },
      { id: 'p3', name: 'Rebalancing Engine', description: 'Strategy alignment service', status: 'healthy' },
      { id: 'p4', name: 'Performance Attribution', description: 'Alpha/Beta analysis', status: 'healthy' },
    ]
  },
  {
    name: 'Order Execution',
    icon: 'Zap',
    services: [
      { id: 'o1', name: 'Smart Order Router', description: 'Best execution pathing', status: 'healthy' },
      { id: 'o2', name: 'FIX Gateway', description: 'Institutional connectivity', status: 'healthy' },
      { id: 'o3', name: 'Matching Engine', description: 'Internal crossing logic', status: 'healthy' },
      { id: 'o4', name: 'Settlement Service', description: 'Post-trade clearing', status: 'healthy' },
    ]
  }
];
